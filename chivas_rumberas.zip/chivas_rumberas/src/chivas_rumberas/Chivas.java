package chivas_rumberas;

public class Chivas 
{
	//-----------------------------------
	//Atributos
	//-------------------------------------
	private String nombre;
	private int capacidadChiva;
	private int cantidadSillas;
	private double precioHora;
	private double horasAlquiladas;
		
	//-----------------------------------------
	//Constructor
	//-----------------------------------------
	public Chivas(String pNombre, int pCapacidadChiva, int pCantidadChivas, double pPrecioHora, double pHorasAlquiladas )
	{
		nombre = pNombre;
		capacidadChiva = pCapacidadChiva;
		cantidadSillas = pCantidadChivas;
		precioHora = pPrecioHora;
		horasAlquiladas = pHorasAlquiladas;
		
	}
	
	//----------------------------------
	//Metodos
	//----------------------------------
	public double calcularRecaudo( )
	{
		return horasAlquiladas * precioHora;
	}
	
	//get
	public String getNombre()
	{
		return nombre;
		
	}
	public int getCapacidadChiva()
	{
		return capacidadChiva;
	
	}
	public int getCantidadSillas()
	{
		return cantidadSillas;
		
	}
	public double getPrecioHora()
	{
		return precioHora;
		
	}
	public double getHorasAlquiladas()
	{
		return horasAlquiladas;
	}
	
	//set
	public  void  setNombre(String pNombre)
	{
		 nombre = pNombre;
		
	}
	public void setCapacidadChiva( int pCapacidadChiva)
	{
		 capacidadChiva = pCapacidadChiva;
	
	}
	public void  setCantidadSillas(int pCantidadSillas)
	{
		cantidadSillas = pCantidadSillas; 
		
	}
	public void setPrecioHora(double pPrecioHora)
	{
		precioHora = pPrecioHora;
		
	}
	public void setHorasAlquiladas(double pHorasAlquiladas)
	{
		horasAlquiladas  = pHorasAlquiladas ;
	}
	
 
}
